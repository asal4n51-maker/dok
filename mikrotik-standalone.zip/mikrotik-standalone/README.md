# MikroTik Standalone Control

Aplikasi mandiri terpisah dari Hachi Net untuk:
- Memantau koneksi kabel LAN di Windows dan otomatis meminta IP DHCP (`Set-NetIPInterface` + `ipconfig /renew`).
- Mendeteksi port Winbox (`8291`) dan membuka `winbox64.exe` otomatis.
- Mengelola rule `/ip firewall mangle` (tambah, lihat daftar, dan hapus).
- Menjalankan `/tool bandwidth-test` cukup dengan mengganti IP server Speedtest.

## Cara Pasang & Jalankan
1. Ekstrak file ZIP ini ke folder tujuan (misalnya `C:\mikrotik-standalone`).
2. Sesuaikan lokasi `WINBOX_PATH` dan kredensial di file `.env` jika diperlukan.
3. Jalankan PowerShell (disarankan sebagai **Administrator** agar Auto-DHCP berjalan lancar):
   ```powershell
   npm.cmd install
   npm.cmd start
   ```
4. Buka browser ke `http://localhost:4000`.
