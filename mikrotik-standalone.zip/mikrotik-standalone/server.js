import 'dotenv/config';
import express from 'express';
import path from 'path';
import net from 'net';
import { fileURLToPath } from 'url';
import { execFile } from 'child_process';
import { promisify } from 'util';

const execFileAsync = promisify(execFile);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT || 4000);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const lanState = {
  autoDhcpEnabled: true,
  autoLaunchEnabled: true,
  cableConnected: false,
  dhcpRenewedForSession: false,
  lastDhcpMessage: null,
  adapters: [],
  detectedMikrotikIp: null,
  lastWinboxLaunchedIp: null,
  lastWinboxLaunchedAt: null,
  lastError: null,
  updatedAt: new Date().toISOString()
};

function runSshCommand(host, user, command) {
  return execFileAsync('ssh', [
    '-o', 'StrictHostKeyChecking=no',
    '-o', 'ConnectTimeout=6',
    `${user}@${host}`,
    command
  ]);
}

function runPowerShell(psScript) {
  return execFileAsync('powershell', [
    '-NoProfile',
    '-NonInteractive',
    '-ExecutionPolicy', 'Bypass',
    '-Command', psScript
  ]);
}

function checkTcpPort(host, port = 8291, timeoutMs = 700) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let settled = false;

    const finish = (result) => {
      if (!settled) {
        settled = true;
        socket.destroy();
        resolve(result);
      }
    };

    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

function launchWinboxProcess(host, user = process.env.MIKROTIK_USER || 'admin', pass = process.env.MIKROTIK_PASS ?? '') {
  const winboxPath = process.env.WINBOX_PATH || 'C:\\Tools\\Winbox\\winbox64.exe';
  const args = pass ? [host, user, pass] : [host, user];
  const child = execFile(winboxPath, args, { windowsHide: false });
  child.unref();
}

async function ensureDhcpOnLanAdapters(adapters) {
  if (process.platform !== 'win32' || !adapters || adapters.length === 0) {
    return { ok: false, message: 'Tidak ada adaptor LAN aktif.' };
  }

  const aliases = adapters.map((a) => `'${String(a.name).replace(/'/g, "''")}'`).join(', ');
  const psScript = [
    `$names = @(${aliases});`,
    'foreach ($n in $names) {',
    '  Set-NetIPInterface -InterfaceAlias $n -Dhcp Enabled -ErrorAction Stop;',
    '  ipconfig /renew $n | Out-Null;',
    '}',
    '$ips = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -in $names -and $_.IPAddress -notlike "169.254.*" } | Select-Object -ExpandProperty IPAddress;',
    '@{ ok = $true; ips = @($ips) } | ConvertTo-Json -Compress'
  ].join(' ');

  const { stdout } = await runPowerShell(psScript);
  const parsed = JSON.parse(stdout || '{}');
  const gotIps = Array.isArray(parsed.ips) && parsed.ips.length > 0 ? parsed.ips.join(', ') : 'menunggu lease DHCP';
  return {
    ok: true,
    message: `DHCP diaktifkan & diperbarui (${gotIps})`
  };
}

async function inspectWindowsLan() {
  if (process.platform !== 'win32') {
    return { connected: false, adapters: [], candidates: [] };
  }

  const psScript = [
    '$up = Get-NetAdapter | Where-Object { $_.Status -eq "Up" -and ($_.InterfaceDescription -match "Ethernet|GbE|PCIe|USB.*LAN|Realtek|Intel") };',
    '$gw = Get-NetIPConfiguration | Where-Object { $_.NetAdapter.Status -eq "Up" -and $_.IPv4DefaultGateway -ne $null } | Select-Object -ExpandProperty IPv4DefaultGateway | Select-Object -ExpandProperty NextHop -Unique;',
    '$ips = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -in $up.Name -and $_.IPAddress -notlike "169.254.*" } | Select-Object -ExpandProperty IPAddress;',
    '@{ connected = [bool]($up -and @($up).Count -gt 0); adapters = @($up | ForEach-Object { @{ name = $_.Name; desc = $_.InterfaceDescription; linkSpeed = $_.LinkSpeed } }); gateways = @($gw); ips = @($ips) } | ConvertTo-Json -Compress'
  ].join(' ');

  const { stdout } = await runPowerShell(psScript);
  const parsed = JSON.parse(stdout || '{}');
  const candidates = new Set([
    ...(Array.isArray(parsed.gateways) ? parsed.gateways : []),
    process.env.MIKROTIK_HOST || '192.168.88.1',
    '192.168.88.1',
    '192.168.1.1',
    '192.168.0.1',
    '10.0.0.1',
    '172.16.0.1'
  ].filter(Boolean));

  if (Array.isArray(parsed.ips)) {
    for (const ip of parsed.ips) {
      const parts = ip.split('.');
      if (parts.length === 4) {
        candidates.add(`${parts[0]}.${parts[1]}.${parts[2]}.1`);
      }
    }
  }

  return {
    connected: Boolean(parsed.connected),
    adapters: Array.isArray(parsed.adapters) ? parsed.adapters : [],
    candidates: Array.from(candidates)
  };
}

async function pollLanAndWinbox() {
  try {
    const info = await inspectWindowsLan();
    lanState.cableConnected = info.connected;
    lanState.adapters = info.adapters;
    lanState.lastError = null;
    lanState.updatedAt = new Date().toISOString();

    if (!info.connected) {
      lanState.dhcpRenewedForSession = false;
      lanState.detectedMikrotikIp = null;
      lanState.lastWinboxLaunchedIp = null;
      return;
    }

    if (lanState.autoDhcpEnabled && !lanState.dhcpRenewedForSession) {
      lanState.dhcpRenewedForSession = true;
      try {
        const dhcpRes = await ensureDhcpOnLanAdapters(info.adapters);
        lanState.lastDhcpMessage = dhcpRes.message;
        console.log(`[LAN Auto-DHCP] ${dhcpRes.message}`);
        const refreshed = await inspectWindowsLan();
        info.candidates = refreshed.candidates;
      } catch (dhcpErr) {
        lanState.lastDhcpMessage = `Gagal minta DHCP (jalankan terminal sebagai Administrator): ${dhcpErr.message}`;
        console.warn(`[LAN Auto-DHCP] ${lanState.lastDhcpMessage}`);
      }
    }

    let foundIp = null;
    for (const ip of info.candidates) {
      const isWinboxOpen = await checkTcpPort(ip, 8291, 650);
      if (isWinboxOpen) {
        foundIp = ip;
        break;
      }
    }

    lanState.detectedMikrotikIp = foundIp;

    if (
      foundIp &&
      lanState.autoLaunchEnabled &&
      lanState.lastWinboxLaunchedIp !== foundIp
    ) {
      try {
        launchWinboxProcess(foundIp);
        lanState.lastWinboxLaunchedIp = foundIp;
        lanState.lastWinboxLaunchedAt = new Date().toISOString();
        console.log(`[LAN Auto-Winbox] Kabel LAN aktif & MikroTik ${foundIp} terdeteksi. Winbox dibuka.`);
      } catch (err) {
        lanState.lastError = `Gagal buka Winbox otomatis: ${err.message}`;
      }
    }
  } catch (err) {
    lanState.lastError = err.message;
    lanState.updatedAt = new Date().toISOString();
  }
}

app.get('/api/lan/status', async (req, res) => {
  if (req.query.refresh === '1') {
    await pollLanAndWinbox();
  }
  res.json({ ok: true, ...lanState });
});

app.post('/api/lan/auto-dhcp', (req, res) => {
  lanState.autoDhcpEnabled = Boolean(req.body?.enabled);
  if (lanState.autoDhcpEnabled) {
    lanState.dhcpRenewedForSession = false;
  }
  res.json({ ok: true, autoDhcpEnabled: lanState.autoDhcpEnabled });
});

app.post('/api/lan/renew-dhcp', async (req, res) => {
  try {
    const info = await inspectWindowsLan();
    if (!info.connected) {
      return res.status(400).json({ ok: false, message: 'Kabel LAN belum terhubung.' });
    }
    const result = await ensureDhcpOnLanAdapters(info.adapters);
    lanState.lastDhcpMessage = result.message;
    return res.json({ ok: true, message: result.message });
  } catch (err) {
    return res.status(500).json({
      ok: false,
      message: `Gagal memperbarui DHCP (pastikan PowerShell dijalankan sebagai Administrator): ${err.message}`
    });
  }
});

app.post('/api/lan/auto-launch', (req, res) => {
  lanState.autoLaunchEnabled = Boolean(req.body?.enabled);
  res.json({ ok: true, autoLaunchEnabled: lanState.autoLaunchEnabled });
});

app.post('/api/winbox/mangle', async (req, res) => {
  const host = String(req.body?.host || lanState.detectedMikrotikIp || process.env.MIKROTIK_HOST || '192.168.88.1').trim();
  const user = String(req.body?.user || process.env.MIKROTIK_USER || 'admin').trim();
  const pass = String(req.body?.password ?? process.env.MIKROTIK_PASS ?? '');

  try {
    launchWinboxProcess(host, user, pass);
    lanState.lastWinboxLaunchedIp = host;
    lanState.lastWinboxLaunchedAt = new Date().toISOString();
    return res.json({
      ok: true,
      host,
      message: `Winbox dibuka ke ${host}. Buka menu IP -> Firewall -> tab Mangle.`
    });
  } catch (err) {
    return res.status(500).json({
      ok: false,
      message: `Gagal membuka Winbox: ${err.message}`
    });
  }
});

app.post('/api/speedtest', async (req, res) => {
  const host = String(req.body?.host || lanState.detectedMikrotikIp || process.env.MIKROTIK_HOST || '192.168.88.1').trim();
  const user = String(req.body?.user || process.env.MIKROTIK_USER || 'admin').trim();
  const serverIp = String(req.body?.serverIp || '').trim();
  const protocol = ['tcp', 'udp'].includes(req.body?.protocol) ? req.body.protocol : 'tcp';
  const direction = ['both', 'transmit', 'receive'].includes(req.body?.direction) ? req.body.direction : 'both';
  const duration = /^[0-9]+[smhd]?$/i.test(String(req.body?.duration || '').trim())
    ? String(req.body.duration).trim()
    : '10s';

  if (!serverIp || !/^[a-zA-Z0-9.:-]+$/.test(serverIp)) {
    return res.status(400).json({ ok: false, message: 'IP server Speedtest tidak valid.' });
  }

  const command = `/tool bandwidth-test address=${serverIp} protocol=${protocol} direction=${direction} duration=${duration}`;

  try {
    const { stdout, stderr } = await runSshCommand(host, user, command);
    return res.json({
      ok: true,
      command,
      output: (stdout || stderr || 'Selesai').trim()
    });
  } catch (err) {
    return res.status(500).json({
      ok: false,
      command,
      message: `Gagal menjalankan speedtest via SSH: ${err.message}`
    });
  }
});

app.get('/api/mangle', async (req, res) => {
  const host = String(req.query?.host || lanState.detectedMikrotikIp || process.env.MIKROTIK_HOST || '192.168.88.1').trim();
  const user = String(req.query?.user || process.env.MIKROTIK_USER || 'admin').trim();

  try {
    const { stdout } = await runSshCommand(host, user, '/ip firewall mangle print detail without-paging');
    const blocks = stdout.split(/\r?\n\s*\r?\n/).map((b) => b.trim()).filter(Boolean);

    const rules = blocks.map((block, index) => {
      const idMatch = block.match(/^\s*(\*?[0-9A-Fa-f]+|\d+)/);
      const chainMatch = block.match(/chain=([^\s]+)/);
      const actionMatch = block.match(/action=([^\s]+)/);
      const dstMatch = block.match(/dst-address=([^\s]+)/);
      const markMatch = block.match(/new-(?:routing|connection|packet)-mark=([^\s]+)/);
      const commentMatch = block.match(/comment="([^"]*)"/) || block.match(/comment=([^\s]+)/);

      return {
        id: idMatch ? idMatch[1] : String(index),
        chain: chainMatch ? chainMatch[1] : '-',
        action: actionMatch ? actionMatch[1] : '-',
        dstAddress: dstMatch ? dstMatch[1] : '-',
        mark: markMatch ? markMatch[1] : '-',
        comment: commentMatch ? commentMatch[1] : '-',
        disabled: /\bdisabled=yes\b/i.test(block)
      };
    });

    return res.json({ ok: true, rules });
  } catch (err) {
    return res.status(500).json({ ok: false, message: `Gagal membaca rule Mangle: ${err.message}` });
  }
});

app.post('/api/mangle', async (req, res) => {
  const host = String(req.body?.host || lanState.detectedMikrotikIp || process.env.MIKROTIK_HOST || '192.168.88.1').trim();
  const user = String(req.body?.user || process.env.MIKROTIK_USER || 'admin').trim();
  const command = String(req.body?.command || '').trim();

  if (!command.startsWith('/ip firewall mangle add ')) {
    return res.status(400).json({ ok: false, message: 'Perintah Mangle tidak valid.' });
  }

  try {
    const { stdout, stderr } = await runSshCommand(host, user, command);
    return res.json({ ok: true, command, output: (stdout || stderr || 'Rule ditambahkan').trim() });
  } catch (err) {
    return res.status(500).json({ ok: false, message: `Gagal menambah rule Mangle: ${err.message}` });
  }
});

app.delete('/api/mangle/:id', async (req, res) => {
  const host = String(req.query?.host || req.body?.host || lanState.detectedMikrotikIp || process.env.MIKROTIK_HOST || '192.168.88.1').trim();
  const user = String(req.query?.user || req.body?.user || process.env.MIKROTIK_USER || 'admin').trim();
  const ruleId = String(req.params.id || '').trim();

  if (!/^\*?[0-9a-zA-Z_-]+$/.test(ruleId)) {
    return res.status(400).json({ ok: false, message: 'ID rule tidak valid.' });
  }

  try {
    await runSshCommand(host, user, `/ip firewall mangle remove [find .id=${ruleId}]`);
    return res.json({ ok: true, message: `Rule ${ruleId} berhasil dihapus.` });
  } catch (_) {
    try {
      await runSshCommand(host, user, `/ip firewall mangle remove ${ruleId}`);
      return res.json({ ok: true, message: `Rule ${ruleId} berhasil dihapus.` });
    } catch (err) {
      return res.status(500).json({ ok: false, message: `Gagal menghapus rule ${ruleId}: ${err.message}` });
    }
  }
});

app.listen(PORT, () => {
  console.log(`MikroTik Standalone Control berjalan di http://localhost:${PORT}`);
  pollLanAndWinbox();
  setInterval(pollLanAndWinbox, 3000);
});
